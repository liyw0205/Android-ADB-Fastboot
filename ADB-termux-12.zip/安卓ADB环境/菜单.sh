#二改请注明来源
#二改勿加恶意命令
bin=/data/user/0/com.termux/files/usr/bin/
adb=$bin/adb
fastboot=$bin/fastboot
xx=>/dev/null 2>&1
export HOME=$bin/adb-tmp
export TMPDIR=$bin/adb-tmp
starta=`date +'%s'`

ys="\e[0m"
#没有样式
ys8="\e[30;40;5m"
#黑色
ys1="\e[37;40;m"
#白色
ys2="\e[31;40;m"
#红色
ys3="\e[32;40;m"
#绿色
ys4="\e[33;40;m"
#黄色
ys5="\e[34;40;m"
#蓝色
ys6="\e[35;40;m"
#紫红色
ys7="\e[36;40;m"
#青蓝色
ppp() {
ppp() {
echo -e "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"    
}
p() {
    echo -e  "\n------------------------------------------------\n"
}

zhuye() {
ppp
p
echo -e $ys3"使用过程如有报错请重新配置ADB环境"$ys
echo -e $ys3"使用MT管理器加黑色主题体验更佳"$ys
echo -e $ys3"MT管理器右下角lm打开键盘"$ys
p
enda=`date +'%s'`
echo -e $ys1"已启用时间：$((enda-starta))s"$ys
p
echo -e $ys4"1.查看ADB设备 2.查看Fastboot设备"$ys
echo -e $ys4"3.adb sideload 4.查看历史adb sideload结果"$ys
echo -e $ys4"5.自定义ADB命令 6.自定义Fastboot命令"$ys
echo -e $ys4"7.查看ADB帮助 8.查看Fastboot帮助"$ys
echo -e $ys4"9.格式化相关"$ys
p
echo -e $ys2"99.配置ADB环境 88.循环申请USB调试"$ys
echo -e $ys2"77.关注作者 66.重启ADB服务"$ys
p
echo -e $ys2"55.下载其他版本 44.退出"$ys
echo -e $ys2"00.加入聊天群"$ys
p
echo -e $ys7"开机状态"$ys
echo -e $ys6"A.重启手机 B.重启至REC"$ys 
echo -e $ys6"C.重启至fastboot D.重启至9008/EDL"$ys
p
echo -e $ys7"Fastboot状态"$ys
echo -e $ys6"E.重启手机 F.重启至REC"$ys 
echo -e $ys6"G.重启至fastboot H.重启至9008/EDL"$ys
p 
  if [ ! $? -eq 0 ]; then
    sleeping
fi
}

tz(){
p
if [[ -d "$bin" ]]; then
if [[ -d "$bin/adb-tmp" ]]; then
if [[ -e "$bin/adb" ]]; then
if [[ -e "$bin/fastboot" ]]; then
printf $ys1"回车继续："$ys
  read a2
  case "$a2" in
      * ) zhuye;;      
      esac
else
tz2
fi
else
tz2
fi
else
tz2
fi
else
tz2
fi
}
  
tz2(){
ppp
p
echo -e $ys2"您还未配置ADB环境或ADB环境残缺"$ys
echo -e $ys2"请尽快配置ADB环境"$ys
p
echo -e $ys2"1.配置ADB环境 2.退出"$ys
p
printf $ys1"请输入："$ys
  read a3
  case "$a3" in
      1 ) hj;zhuye;;
      2 ) exxit;;
      * ) exxit;;      
      esac
}

adb(){
ppp
p
echo -e $ys4"自定义ADB命令"$ys
echo -e $ys1"温馨提示：命令加-d"
p
printf $ys1"请输入："$ys
  read a4
$bin$a4
}

fastboot(){
p
echo -e $ys4"自定义Fastboot命令"$ys
printf $ys1"请输入："$ys
  read a5
$bin$a5
}

xzqtbb(){
p
echo -e $ys1"蓝奏云：https://wwat.lanzoul.com/b031wep9a"$ys
echo -e $ys1"密码：e6qo"$ys
echo -e $ys1"Github：https://github.com/liyw0205/Android-ADB-Fastboot"$ys
}

exxit(){
ppp
enda=`date +'%s'`
echo -e $ys"本次使用时间：$((enda-starta))s"$ys
echo -e $ys"欢迎下次使用"$ys
exit
}

zz(){
p
if [[ "$(pm list package | grep -w 'com.coolapk.market')" != "" ]];then
am start -d 'coolmarket://u/19926645' >/dev/null 2>&1
else
echo -e $ys2"请安装酷安"$ys
am start -d 'https://www.coolapk.com/apk/com.coolapk.market' >/dev/null 2>&1
fi
}

ltq(){
p
if [[ "$(pm list package | grep -w 'com.tencent.mobileqq')" != "" ]];then
am start -d 'https://jq.qq.com/?_wv=1027&k=aAxbb7rr' >/dev/null 2>&1
else
echo -e $ys2"请安装QQ"$ys
am start -d 'https://im.qq.com/immobile/android/?_wwv=512' >/dev/null 2>&1
fi
}


sideload(){
a=`$bin/adb devices -l | grep -v -i 'List of .*' | grep -v -i 'emulator-5554'`
if [[ -n `echo "$a" | grep -i 'sideload'` ]]; then
printf $ys2"请输入zip的绝对路径："$ys
  read a4
  case "$a4" in
      * ) sideload1;tz;;      
      esac
else
echo -e $ys2"！无设备连接sideload模式"$ys
fi
}

sideload1(){
ppp
p
echo -e $ys2"请耐心等待"$ys
$adb -d sideload $a4
export side="${?}"
case "${side}" in
0 )
echo -e $ys2"刷入成功"$ys
export sid="0"
;;
1 )
echo -e $ys2"文件丢失或刷入失败"$ys
export sid="1"
;;
127 )
echo -e $ys2"adb文件丢失，请重新配置环境"$ys
export sid="127"
;;
* )
echo -e $ys2"未知错误"$ys
export sid="*"
;;
esac
}

sideload2(){
case "$sid" in
0 )
echo -e $ys2"上次sideload线刷非常成功"$ys
;;
1 )
echo -e $ys2"上次sideload线刷遇到了错误，可能丢失了文件或者刷入失败"$ys
;;
127 )
echo -e $ys2"上次sideload线刷发生了环境丢失"$ys
;;
* )
echo -e $ys2"上次sideload线刷遇到了未知错误"$ys
;;
esac
}

format(){
ppp
p
echo -e $ys2"1.格式化data 2.恢复出厂设置"$ys
p
  printf "$ys请输入："
  read a1
  case "$a1" in
     1 ) data;tz;;
     2 ) www;tz;;
     esac
}

data(){
echo -e $ys2"5秒后格式化data，如后悔直接Ctrl+C退出脚本或拔线"$ys
for i in $(seq +1 5);do
echo -e $i
sleep 1
done
p
fb=`$fastboot devices`
if [[ -n `echo "$fb" | grep -i 'fastboot'` ]]; then
$fastboot devices
$fastboot erase userdata $xx
$fastboot erase cache $xx
$fastboot erase metadata $xx
$fastboot -w $xx
$fastboot format data $xx
echo -e $ys2"已为您格式化data"$ys
else
echo -e $ys2"！无FASTBOOT设备连接"$ys
fi
}

www(){
echo -e $ys2"5秒后恢复出厂设置，如后悔直接Ctrl+C退出脚本或拔线"$ys
for i in $(seq +1 5);do
echo -e $i
sleep 1
done
p
fb=`$fastboot devices`
if [[ -n `echo "$fb" | grep -i 'fastboot'` ]]; then
$fastboot devices
$fastboot erase userdata $xx
$fastboot erase cache $xx
$fastboot erase metadata $xx
$fastboot -w $xx
echo -e $ys2"已为您恢复出厂设置"$ys
else
echo -e $ys2"！无FASTBOOT设备连接"$ys
fi
}

hj(){
abi=`getprop ro.product.cpu.abi`
ppp
p
echo -e $ys3"检测环境中…"$ys
if [[ -d "$bin" ]]; then
hj2
else
echo -e $ys3"正在创建环境运行目录：$ys2$bin"$ys
mkdir $bin
hj2
fi
}

hj2(){
if [[ -n `echo "$abi" | grep -i 'arm64-v8a'` ]]; then
sleep 1
echo -e " "
echo -e $ys3"您的设备CPU是：$ys2$abi"$ys
echo -e " "
echo -e $ys3"自动配置ADB环境…"$ys
echo -e " "
cp -af bin/binary/$abi/adb $bin $xx
cp -af bin/binary/$abi/fastboot $bin $xx
mkdir -p $bin/adb-tmp $xx
chmod -R 777 $bin/fastboot $xx
chmod -R 777 $bin/adb $xx

sleep 2
echo -e $ys2"配置完成…"$ys
p
echo -e $ys2"三秒后加载到主页…"$ys
for i in $(seq +1 3);do
echo -e $i
sleep 1
done
else
if [[ -n `echo "$abi" | grep -i 'armeabi-v7a'` ]]; then
sleep 1
echo -e " "
echo -e $ys3"您的设备CPU是：$ys2$abi"$ys
echo -e " "
echo -e $ys3"自动配置ADB环境…"$ys
echo -e " "
cp -af bin/binary/$abi/adb $bin $xx
cp -af bin/binary/$abi/fastboot $bin $xx
mkdir -p $bin/adb-tmp $xx
chmod -R 777 $bin/fastboot $xx
chmod -R 777 $bin/adb $xx

sleep 2
echo -e $ys2"配置完成…"$ys
p
echo -e $ys2"三秒后加载到主页…"$ys
for i in $(seq +1 3);do
echo -e $i
sleep 1
done
else
if [[ -n `echo "$abi" | grep -i 'x86'` ]]; then
sleep 1
echo -e " "
echo -e $ys3"您的设备CPU是：$ys2$abi"$ys
echo -e " "
echo -e $ys3"自动配置ADB环境…"$ys
echo -e " "
cp -af bin/binary/$abi/adb $bin $xx
cp -af bin/binary/$abi/fastboot $bin $xx
mkdir -p $bin/adb-tmp $xx
chmod -R 777 $bin/fastboot $xx
chmod -R 777 $bin/adb $xx

sleep 2
echo -e $ys2"配置完成…"$ys
p
echo -e $ys2"三秒后加载到主页…"$ys
for i in $(seq +1 3);do
echo -e $i
sleep 1
done
else
if [[ -n `echo "$abi" | grep -i 'x86_64'` ]]; then
sleep 1
echo -e " "
echo -e $ys3"您的设备CPU是：$ys2$abi"$ys
echo -e " "
echo -e $ys3"自动配置ADB环境…"$ys
echo -e " "
cp -af bin/binary/$abi/adb $bin $xx
cp -af bin/binary/$abi/fastboot $bin $xx
mkdir -p $bin/adb-tmp $xx
chmod -R 777 $bin/fastboot $xx
chmod -R 777 $bin/adb $xx

sleep 2
ppp
p
echo -e $ys2"配置完成…"$ys
p
echo -e $ys2"三秒后加载到主页…"$ys
for i in $(seq +1 3);do
echo -e $i
sleep 1
done
else
p
echo -e $ys2"不支持的CPU：$abi"$ys
exit
fi
fi
fi
fi
}

restart(){

$bin/adb kill-server $xx
$bin/adb start-server $xx
p
echo -e $ys3"重启完成"$ys
}

usb(){
fb=`$fastboot devices`
a=`$bin/adb devices -l | grep -v -i 'List of devices attached' | grep -v -i 'emulator-5554'`
if [[ -n `echo "$a" | grep -i 'device'` ]]; then
sleep 1
ppp
p
echo -e $ys2"已获得USB调试！"$ys
$bin/adb devices | grep -v -i 'List of .*' | grep -v -i 'emulator-5554'
else
if [[ -n `echo "$a" | grep -i 'recovery'` ]]; then
sleep 1
ppp
p
echo -e $ys2"已获得USB调试！"$ys
$bin/adb devices | grep -v -i 'List of .*' | grep -v -i 'emulator-5554'
else
if [[ -n `echo "$a" | grep -i 'sideload'` ]]; then
sleep 1
ppp
p
echo -e $ys2"已获得USB调试！"$ys
$bin/adb devices | grep -v -i 'List of .*' | grep -v -i 'emulator-5554'
else
if [[ -n `echo "$fb" | grep -i 'fastboot'` ]]; then
sleep 1
ppp
p
echo -e $ys2"已获得Fastboot设备！"$ys
echo -e $ys2"你小子不走寻常路！"$ys
$fastboot devices
else
p
echo -e $ys3"未授权USB调试，已重新申请授权"$ys
sleep 1
usb
fi
fi
fi
fi
}

ck1(){
ppp
p
a=`$bin/adb devices -l | grep -v -i 'List of devices attached' | grep -v -i 'emulator-5554'`
if [[ -n `echo "$a" | grep -i 'device'` ]]; then
echo -e $ys4"获取设备列表及设备状态"$ys
$adb devices | grep -v -i 'List of .*' | grep -v -i 'emulator-5554' | sed -e 's/device$/　设备已连接/g' -e 's/offline$/　设备已离线/g' -e 's/unauthorized$/　没有允许授权USB调试/g ' -e 's/recovery$/　设备已连接recovery模式/g ' -e 's/sideload$/　设备已连接sideload模式/g '
    Number=`$adb devices | grep -v -i 'List of devices attached' | grep -v -i 'emulator-5554' | wc -l`
    if [[ "$Number" -gt 2 ]]; then
        echo -e $ys2"！多个设备连接"$ys
        echo -e "$a"
    fi
else
echo -e $ys2"！无设备连接"$ys
fi
}

ck2(){
ppp
p
fb=`$fastboot devices`
if [[ -n `echo "$fb" | grep -i  'fastboot'` ]]; then
$fastboot devices
else
    echo -e $ys2"！无FASTBOOT设备连接"$ys
fi
}

cq(){
ppp
p
a=`$bin/adb devices -l | grep -v -i 'List of .*'`
if [[ -n `echo "$a" | grep -i 'device'` ]]; then
$adb -d reboot
echo -e $ys2"已为您重启设备"$ys
else
echo -e $ys2"！无设备连接"$ys
fi
}

cq2(){
ppp
p
fb=`$fastboot devices`
if [[ -n `echo "$fb" | grep -i 'fastboot'` ]]; then
$fastboot devices
$fastboot reboot 
echo -e $ys2"已为您重启设备"$ys
else
echo -e $ys2"！无FASTBOOT设备连接"$ys
fi
}

rec(){
ppp
p
a=`$bin/adb devices -l | grep -v -i 'List of .*'`
if [[ -n `echo "$a" | grep -i 'device'` ]]; then
$adb -d reboot recovery
echo -e $ys2"已为您重启到REC"$ys
else
echo -e $ys2"！无设备连接"$ys
fi
}

rec2(){
ppp
p
fb=`$fastboot devices`
if [[ -n `echo "$fb" | grep -i 'fastboot'` ]]; then
$fastboot devices
$fastboot reboot-recovery
echo -e $ys2"已为您重启到REC"$ys
else
echo -e $ys2"！无FASTBOOT设备连接"$ys
fi
}
  
fb(){
ppp
p
a=`$bin/adb devices -l | grep -v -i 'List of .*'`
if [[ -n `echo "$a" | grep -i 'device'` ]]; then
$adb -d reboot bootloader
echo -e $ys2"已为您重启到Fastboot"$ys
else
echo -e $ys2"！无设备连接"$ys
fi
}



fb2(){
ppp
p
fb=`$fastboot devices`
if [[ -n `echo "$fb" | grep -i 'fastboot'` ]]; then
$fastboot devices
$fastboot reboot-bootloader
echo -e $ys2"已为您重启到Fastboot"$ys
else
echo -e $ys2"！无FASTBOOT设备连接"$ys
fi
}

edl(){
ppp
p
a=`$bin/adb devices -l | grep -v -i 'List of .*'`
if [[ -n `echo "$a" | grep -i 'device'` ]]; then
$adb -d reboot edl
echo -e $ys2"已为您重启至9008/EDL"$ys
echo -e $ys2"如果长按电源键无法退出9008，可以尝试按住电源音量加音量减一起长按"$ys
else
echo -e $ys2"！无设备连接"$ys
fi
}



edl2(){
ppp
p
fb=`$fastboot devices`
if [[ -n `echo "$fb" | grep -i 'fastboot'` ]]; then
$fastboot devices
$fastboot oem edl
echo -e $ys2"已为您重启至9008/EDL"$ys
echo -e $ys2"如果长按电源键无法退出9008，可以尝试按住电源音量加音量减一起长按"$ys
else
echo -e $ys2"！无FASTBOOT设备连接"$ys
fi
}

qqq(){
if [ ! -d "bin/" ];then
echo -e $ys2"不解压就想用？"$ys
echo -e $ys1"╭◜◝ ͡ ◜◝╮"$ys
echo -e $ys1"( ˃̶͈◡˂̶͈ )大家快来看这个傻子，傻了吧唧的！"$ys
echo -e $ys1"╰◟◞ ͜ ◟◞╯"$ys
p
exit
else
zhuye
fi
}
qqq

while [ 1 ]
do
zhuye
printf $ys1"请输入："$ys
read a1
  case "$a1" in
     99 ) hj;;
     88 ) usb;tz;;
     77 ) zz;tz;;
     66 ) restart;tz;;
     55 ) xzqtbb;tz;;
     44 ) exxit;;
     00 ) ltq;tz;;
      1 ) ck1;tz;;
      2 ) ck2;tz;;
      3 ) sideload;tz;;
      4 ) sideload2;tz;;
      5 ) adb;tz;;
      6 ) fastboot;tz;;
      7 ) adbhelp;tz;;
      8 ) fastboothelp;tz;;
      9 ) format;tz;;
      a ) cq;tz;;
      b ) rec;tz;;
      c ) fb;tz;;
      d ) edl;tz;;
      e ) cq2;tz;;
      f ) rec2;tz;;
      g ) fb2;tz;;
      h ) edl2;tz;;
      A ) cq;tz;;
      B ) rec;tz;;
      C ) fb;tz;;
      D ) edl;tz;;
      E ) cq2;tz;;
      F ) rec2;tz;;
      G ) fb2;tz;;
      H ) edl2;tz;;
      * ) zhuye;;
    esac
done